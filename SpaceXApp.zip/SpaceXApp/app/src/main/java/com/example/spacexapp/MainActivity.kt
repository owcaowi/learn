package com.example.spacexapp

import android.support.v7.app.AppCompatActivity
import android.os.Bundle
import android.support.v7.widget.LinearLayoutManager
import com.github.kittinunf.fuel.httpGet
import kotlinx.android.synthetic.main.activity_main.*

class MainActivity : AppCompatActivity() {

    val AllLaunchesUrl = "https://api.spacexdata.com/v3/launches"
    val UpcomingLaunchesUrl = "https://api.spacexdata.com/v3/launches/upcoming"
    val PastLaunchesUrl = "https://api.spacexdata.com/v3/launches/past"

    val Launches = ArrayList<LaunchDAO>()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        searchForLaunches(AllLaunchesUrl)
        setListeners()
    }

    private fun setListeners() {
        all_launches.setOnClickListener { searchForLaunches(AllLaunchesUrl) }
        past_launches.setOnClickListener { searchForLaunches(PastLaunchesUrl) }
        upcoming_launches.setOnClickListener { searchForLaunches(UpcomingLaunchesUrl) }
    }

    private fun searchForLaunches(AllLaunchesUrl: String) {

        AllLaunchesUrl.httpGet().responseObject(LaunchDAO.Deserializer()) { request, response, result ->
            val (launches, err) = result

            launches?.forEach { launch ->
                Launches.add(launch)
            }

            listView.layoutManager = LinearLayoutManager(this)
            listView.adapter = LaunchAdapter(Launches){}
        }
    }
}
