package com.example.spacexapp

import com.github.kittinunf.fuel.core.ResponseDeserializable
import com.google.gson.Gson
import java.util.*
import kotlin.collections.ArrayList

data class LaunchDAO(

    val launch_success: Boolean?,
    val launch_date_utc: Date?,
    val links: Links?,
    val mission_name: String?,
    val rocket: Rocket?

){
    class Deserializer: ResponseDeserializable<Array<LaunchDAO>> {
        override fun deserialize(content: String): Array<LaunchDAO>?
                = Gson().fromJson(content, Array<LaunchDAO>::class.java)
    }
}

class Links (

    val wikipedia: String?,
    val mission_patch: String?
    //TODO
    //val flickr_images: ArrayList<String>?

)

class Rocket(
    val rocket_name: String?
)
