package com.example.spacexapp

import android.support.v7.widget.RecyclerView
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import com.squareup.picasso.Picasso
import kotlinx.android.synthetic.main.launch_listview_item.view.*

class LaunchAdapter(val launchesList: ArrayList<LaunchDAO>, val listener: (LaunchDAO) -> Unit)
    : RecyclerView.Adapter<LaunchAdapter.LaunchHolder>() {

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): LaunchHolder {
        return LaunchHolder(parent.inflate(R.layout.launch_listview_item))
    }

    fun ViewGroup.inflate(layoutRes: Int): View {
        return LayoutInflater.from(context).inflate(layoutRes, this, false)
    }

    override fun getItemCount(): Int {
        return launchesList.size
    }

    override fun onBindViewHolder(holder: LaunchHolder, position: Int) {
        holder.bind(launchesList.get(position), listener)
    }

    class LaunchHolder(view: View?) : RecyclerView.ViewHolder(view) {

        fun bind(item: LaunchDAO, listener: (LaunchDAO) -> Unit) = with(itemView) {

            //TODO
            mission_name.text = item.mission_name
            status.text = item.launch_success.toString()
            date.text = item.launch_date_utc.toString()
            launch_image.loadUrl(item.links!!.mission_patch.toString())
            //setOnClickListener { listener(item) }
        }

        fun ImageView.loadUrl(url: String) {
            Picasso.with(context).load(url).into(this)
        }

    }

}

