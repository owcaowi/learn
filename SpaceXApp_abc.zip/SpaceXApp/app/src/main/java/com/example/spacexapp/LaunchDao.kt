package com.example.spacexapp

import android.arch.persistence.room.Dao
import android.arch.persistence.room.Insert
import android.arch.persistence.room.Query

@Dao
interface LaunchDao {

    @Query("SELECT * FROM launch")
    fun getAll(): Array<Launch>

    @Insert
    fun insertAll(vararg launches: Array<Launch?>)

//    @Delete
//    fun delete(launch: Launch)

}