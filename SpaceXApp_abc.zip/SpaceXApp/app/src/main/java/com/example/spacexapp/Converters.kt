package com.example.spacexapp

import android.arch.persistence.room.TypeConverter
import java.util.*
import kotlin.collections.ArrayList

class Converters {
    @TypeConverter
    fun fromTimestamp(value: Long?): Date? {
        return value?.let { Date(it) }
    }

    @TypeConverter
    fun dateToTimestamp(date: Date?): Long? {
        return date?.time?.toLong()
    }

    @TypeConverter
    fun fromArrayList(list: ArrayList<Launch>): Array<Launch?> {
        val result : Array<Launch?> = arrayOfNulls<Launch>(list.size)
        list.toArray(result)
        return result
    }

    @TypeConverter
    fun toArrayList(list: Array<Launch>?): ArrayList<Launch>? {
        var result  = ArrayList<Launch>()
        list?.forEach { launch ->
            result.add(launch)
        }
        return result
    }


}