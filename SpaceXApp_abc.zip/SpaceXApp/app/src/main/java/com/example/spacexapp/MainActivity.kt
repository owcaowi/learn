package com.example.spacexapp

import android.arch.persistence.room.Room
import android.support.v7.app.AppCompatActivity
import android.os.Bundle
import android.support.v7.widget.DividerItemDecoration
import android.util.Log
import android.widget.LinearLayout
import com.github.kittinunf.fuel.httpGet
import kotlinx.android.synthetic.main.activity_main.*

class MainActivity : AppCompatActivity() {

    val BASE_URL = "https://api.spacexdata.com/v3/launches"

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        searchForLaunches(BASE_URL)
        setListeners()
    }

    fun setListeners() {
        all_launches.setOnClickListener { searchForLaunches(BASE_URL) }
        past_launches.setOnClickListener { searchForLaunches(BASE_URL.plus("/past")) }
        upcoming_launches.setOnClickListener { searchForLaunches(BASE_URL.plus("/upcoming")) }
    }

    fun searchForLaunches(url: String) {

        url.httpGet().responseObject(Launch.Deserializer()) { request, response, result ->
            val (launches, err) = result

            setDataToView(launches)
           // storeInDataBase(launches)
        }
    }

    fun setDataToView(launches: ArrayList<Launch>?) {

        listView.adapter = LaunchAdapter(launches!!) {}
        listView.adapter.notifyDataSetChanged()

        if (listView.itemDecorationCount == 0) {
            listView.addItemDecoration(DividerItemDecoration(this, LinearLayout.VERTICAL))
        }
    }


    fun storeInDataBase(launches: ArrayList<Launch>){


        val result : Array<Launch?> = arrayOfNulls<Launch>(launches.size)
        launches.toArray(result)


        val db = Room.databaseBuilder(applicationContext, AppDatabase::class.java, "launch").build()
        db.launchDao().insertAll(result)
     //  var newList: Array<Launch> = db.launchDao().getAll()



        Log.d("","")
    }

}
