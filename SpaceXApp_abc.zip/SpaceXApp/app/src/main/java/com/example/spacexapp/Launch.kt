package com.example.spacexapp

import android.arch.persistence.room.*
import com.github.kittinunf.fuel.core.ResponseDeserializable
import com.google.gson.Gson
import com.google.gson.reflect.TypeToken
import java.util.*

@Entity(tableName = "launch")
data class Launch(
    @PrimaryKey(autoGenerate = true)
    @ColumnInfo(name = "launch_success") var launch_success: Boolean,
    @ColumnInfo(name = "launch_date_utc") var launch_date_utc: Date?,
    @Ignore var links: Links,
    @ColumnInfo(name = "mission_name") var mission_name: String?,
    @Ignore var rocket: Rocket?
) {

    constructor() : this(false, null, Links("",""), "",null)

    class Deserializer : ResponseDeserializable<ArrayList<Launch>> {
        val turnsType = object : TypeToken<List<Launch>>() {}.type
        override fun deserialize(content: String): ArrayList<Launch>? = Gson().fromJson(content, turnsType)
    }

}

data class Links(
    var wikipedia: String?,
    var mission_patch: String?
)

data class Rocket(
   var rocket_name: String?
)
